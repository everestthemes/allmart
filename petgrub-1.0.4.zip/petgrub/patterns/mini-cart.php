<?php
/**
 * Title: Mini Cart Default
 * Slug: petgrub/mini-cart-default
 * Categories: petgrub
 *
 * @package petgrub
 */

?>
<!-- wp:woocommerce/mini-cart-contents -->
<div class="wp-block-woocommerce-mini-cart-contents"><!-- wp:woocommerce/filled-mini-cart-contents-block -->
    <div class="wp-block-woocommerce-filled-mini-cart-contents-block"><!-- wp:woocommerce/mini-cart-title-block -->
    <div class="wp-block-woocommerce-mini-cart-title-block"><!-- wp:woocommerce/mini-cart-title-label-block -->
    <div class="wp-block-woocommerce-mini-cart-title-label-block"></div>
    <!-- /wp:woocommerce/mini-cart-title-label-block -->
    
    <!-- wp:woocommerce/mini-cart-title-items-counter-block -->
    <div class="wp-block-woocommerce-mini-cart-title-items-counter-block"></div>
    <!-- /wp:woocommerce/mini-cart-title-items-counter-block --></div>
    <!-- /wp:woocommerce/mini-cart-title-block -->
    
    <!-- wp:woocommerce/mini-cart-items-block -->
    <div class="wp-block-woocommerce-mini-cart-items-block"><!-- wp:woocommerce/mini-cart-products-table-block -->
    <div class="wp-block-woocommerce-mini-cart-products-table-block"></div>
    <!-- /wp:woocommerce/mini-cart-products-table-block --></div>
    <!-- /wp:woocommerce/mini-cart-items-block -->
    
    <!-- wp:woocommerce/mini-cart-footer-block -->
    <div class="wp-block-woocommerce-mini-cart-footer-block"><!-- wp:woocommerce/mini-cart-cart-button-block -->
    <div class="wp-block-woocommerce-mini-cart-cart-button-block"></div>
    <!-- /wp:woocommerce/mini-cart-cart-button-block -->
    
    <!-- wp:woocommerce/mini-cart-checkout-button-block -->
    <div class="wp-block-woocommerce-mini-cart-checkout-button-block"></div>
    <!-- /wp:woocommerce/mini-cart-checkout-button-block --></div>
    <!-- /wp:woocommerce/mini-cart-footer-block --></div>
    <!-- /wp:woocommerce/filled-mini-cart-contents-block -->
    
    <!-- wp:woocommerce/empty-mini-cart-contents-block -->
    <div class="wp-block-woocommerce-empty-mini-cart-contents-block"><!-- wp:group {"layout":{"type":"constrained"}} -->
    <div class="wp-block-group"><!-- wp:image {"id":480,"width":"80px","sizeSlug":"large","linkDestination":"none","align":"center"} -->
    <figure class="wp-block-image aligncenter size-large is-resized"><img src="http://petgrub.local/wp-content/uploads/2024/09/icon-empty-cart.svg" alt="" class="wp-image-480" style="width:80px"/></figure>
    <!-- /wp:image -->
    
    <!-- wp:paragraph {"align":"center"} -->
    <p class="has-text-align-center"><strong>Your Shopping Cart is Empty</strong></p>
    <!-- /wp:paragraph -->
    
    <!-- wp:woocommerce/mini-cart-shopping-button-block {"className":"is-style-outline"} -->
    <div class="wp-block-woocommerce-mini-cart-shopping-button-block is-style-outline"></div>
    <!-- /wp:woocommerce/mini-cart-shopping-button-block --></div>
    <!-- /wp:group --></div>
    <!-- /wp:woocommerce/empty-mini-cart-contents-block --></div>
    <!-- /wp:woocommerce/mini-cart-contents -->
